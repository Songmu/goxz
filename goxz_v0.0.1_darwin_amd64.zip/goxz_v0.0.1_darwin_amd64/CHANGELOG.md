# Changelog

## [v0.0.1](https://github.com/Songmu/goxz/compare/...v0.0.1) (2017-12-26)

* Initial implement [#1](https://github.com/Songmu/goxz/pull/1) ([Songmu](https://github.com/Songmu))